"""Skriv kode, test at all annen kode funker smooth"""
from calculator import Calculator

MY_CALC = Calculator()
print(MY_CALC.calculate_expression('SQRT(4)'))
